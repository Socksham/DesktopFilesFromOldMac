var lat_shelter;
var long_shelter;

var distances = [];

var closest = [];

document.addEventListener("keydown", function(e){
    if(e.keyCode===13){
        lat_shelter = document.getElementById("latitude").value;
        long_shelter = document.getElementById("longitude").value;
        findNearestRestaurants();
    }
})

function findNearestRestaurants(){
    for(var i=0; i < lat_restaurant.length-1; i++){
        distanceFormula(lat_shelter, long_shelter, lat_restaurant[i], long_restaurant[i])
    }
    console.log(distances);

    for(var j=0; j < 3; j++){
        closest.push(Math.min(...distances));
        distances.splice(distances.indexOf(Math.min(...distances)), distances.indexOf(Math.min(...distances)) + 1)
    }
    document.getElementById("print").innerHTML = closest
}

function distanceFormula(latitude_shelter, longitude_shelter, latitude_restaurant, longitude_restaurant){
    var a = latitude_shelter - latitude_restaurant;
    var b = longitude_shelter - longitude_restaurant;
    var distance = Math.sqrt(a*a + b*b);
    distances.push(distance)
}